moved = False

def on_button_grab(ctx, tag):
    global moved
    if moved:
        return
    if tag in ("LB-1", "LB-2"):
        moved = True
        ctx.log(f"Схватились за {tag} — опускаю L-1..L-5 на 100 по Y")
        for i in range(1, 6):
            obj_id = f"L-{i}"
            obj = ctx.by_id(obj_id)
            if obj is None:
                ctx.log(f"Объект {obj_id} не найден")
                continue
            # ВАЖНО: move_to задаёт абсолютную координату.
            # Предполагается, что L-1..L-5 изначально стоят на Y = 0.
            # Если ось Y направлена вверх — замените 100 на -100.
            ctx.move_to(obj, y=100, dur=0.5, ease="out")