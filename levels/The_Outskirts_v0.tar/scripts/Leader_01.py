moved = False

def on_button_press(ctx, tag):
    global moved
    if moved:
        return
    if tag in ("LB-1", "LB-2"):
        moved = True
        ctx.log(f"Кнопка {tag} захвачена — опускаю L-1..L-5 на 100 по Y")
        for i in range(1, 6):
            obj_id = f"L-{i}"
            obj = ctx.by_id(obj_id)
            if obj is not None:
                # ВАЖНО: предполагается, что объекты изначально находятся на Y = 0.
                # Тогда "опустить на 100" = переместить в Y = 100.
                # Если в вашей системе Y направлен вверх, замените 100 на -100.
                ctx.move_to(obj, y=-100, dur=0.5, ease="out")
            else:
                ctx.log(f"Объект {obj_id} не найден")