import math

LAMP_ID       = "lamp_1"       # ← впиши id своей лампы
FLICKER_PROB  = 0.08            # шанс мигнуть за тик (20 Гц) → ~1.6 раза/сек
DIM_TIME      = 0.06            # сколько лампа "проваливается", сек
NORMAL_INT    = 1.0             # базовая яркость
DIM_INT       = 0.15            # яркость в момент мига

# Погрешность цвета относительно исходного цвета лампы
COLOR_JITTER  = 40              # ± по каждому каналу, 0..255


def on_load(ctx):
    lamp = ctx.by_id(LAMP_ID)
    if lamp is None:
        ctx.log(f"lamp {LAMP_ID!r} not found")
        return
    # запоминаем исходные значения
    ctx._lamp = lamp
    ctx._base_color = tuple(getattr(lamp, "color", (255, 255, 255)))
    ctx._base_int = float(getattr(lamp, "intensity", NORMAL_INT))
    ctx._dim_left = 0.0
    ctx._dim_color = None
    ctx.log(f"flicker ready: {LAMP_ID}, base={ctx._base_color}, int={ctx._base_int}")


def _jittered_color(ctx):
    r, g, b = ctx._base_color
    j = COLOR_JITTER
    return (
        max(0, min(255, r + ctx.random.randint(-j, j))),
        max(0, min(255, g + ctx.random.randint(-j, j))),
        max(0, min(255, b + ctx.random.randint(-j, j))),
    )


def on_tick(ctx):
    lamp = getattr(ctx, "_lamp", None)
    if lamp is None:
        return

    # если сейчас "провал" — ждём его окончания
    if ctx._dim_left > 0:
        ctx._dim_left -= 1 / 20
        return

    # случайное мигание
    if ctx.random.random() < FLICKER_PROB:
        ctx._dim_left = DIM_TIME
        ctx._dim_color = _jittered_color(ctx)
        lamp.intensity = DIM_INT
        try:
            lamp.color = ctx._dim_color
        except Exception:
            pass
        return

    # вне мигания — возвращаем базовый цвет с лёгким дрожанием
    lamp.intensity = ctx._base_int
    try:
        lamp.color = _jittered_color(ctx)
    except Exception:
        pass


def on_unload(ctx):
    # восстановить исходное состояние
    lamp = getattr(ctx, "_lamp", None)
    if lamp is None:
        return
    try:
        lamp.intensity = ctx._base_int
        lamp.color = ctx._base_color
    except Exception:
        pass